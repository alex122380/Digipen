Environment: Windows 10
Python version: 3.9.1
Packages used: numpy, pandas, matplotlib(for function plot), PyQt5(for button GUI)

The project was edited and tested in python's IDLE Shell 3.9.1. 
The packages used are installed through windows powershell. 
"pip install matplotlib"
"pip install PyQt5"

The .py file is made into .exe through pyinstaller.
"pip install pyinstaller"
"pyinstaller --onefile --windowed MAT300_Project4_YiChunChen.py"